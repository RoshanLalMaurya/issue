<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\employeeController;
use App\Http\Controllers\schoolController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('hello',function()   {
   return view('First'); 
});


//Products Route
Route::get('products', [ProductController::class, 'index'])->name('products.index');
Route::get('products/create', [ProductController::class, 'create'])->name('products.create');
Route::get('products/{id}', [ProductController::class, 'show'])->name('products.show');
Route::get('products/edit/{id}', [ProductController::class, 'edit'])->name('products.edit');
Route::post('products', [ProductController::class, 'store'])->name('products.store');
Route::put('products/{id}', [ProductController::class, 'update'])->name('products.update');
Route::delete('products/{id}', [ProductController::class, 'destroy'])->name('products.destroy');

//Empolyee Route
Route::get('employee', [employeeController::class, 'index'])->name('employee.index');
Route::get('employee/create', [employeeController::class, 'create'])->name('employee.create');
Route::get('employee/{id}', [employeeController::class, 'show'])->name('employee.show');
Route::get('employee/edit/{id}', [employeeController::class, 'edit'])->name('employee.edit');
Route::post('emloyee', [employeeController::class, 'store'])->name('employee.store');
Route::put('employee/{id}', [employeeController::class, 'update'])->name('employee.update');
Route::delete('employee/{id}', [employeeController::class, 'destroy'])->name('employee.destroy');


//school Route
Route::get('school', [schoolController::class, 'index'])->name('school.index');
Route::get('school/create', [schoolController::class, 'create'])->name('school.create');
Route::get('school/{id}', [schoolController::class, 'show'])->name('school.show');
Route::get('school/edit/{id}', [schoolController::class, 'edit'])->name('school.edit');
Route::post('school', [schoolController::class, 'store'])->name('school.store');
Route::put('school/{id}', [schoolController::class, 'update'])->name('school.update');
Route::delete('school/{id}', [schoolController::class, 'destroy'])->name('school.destroy');